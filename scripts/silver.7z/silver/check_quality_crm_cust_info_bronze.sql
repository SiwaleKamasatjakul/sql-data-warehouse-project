-- Check For Nulls or Duplicates in Primary Key 
-- Expectation: No Result

/*

SELECT 
cst_id,
COUNT(*)
FROM bronze.crm_cust_info
GROUP BY cst_id
HAVING COUNT(*) > 1 OR cst_id IS NULL

 */


-- Check for unwanted Spaces 
-- Expectation: No Results
/*

SELECT cst_firstname
From bronze.crm_cust_info
WHERE cst_firstname != TRIM(cst_firstname)


SELECT cst_gndr
From bronze.crm_cust_info
WHERE cst_gndr != TRIM(cst_gndr)

 */

-- Data Standardization & Consistency
/*
SELECT DISTINCT cst_gndr
FROM bronze.crm_cust_info
 */


-- Result cst_gndr show only unique data to check what data it is 

SELECT DISTINCT cst_marital_status
FROM bronze.crm_cust_info