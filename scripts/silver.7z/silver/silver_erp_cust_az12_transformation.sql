PRINT '>> Truncating Table: silver.erp_cust_az12'
TRUNCATE TABLE silver.erp_cust_az12;
PRINT '>> Insert Data Into: silver.erp_cust_az12'

INSERT INTO silver.erp_cust_az12(cid,bdate,gen)

SELECT
-- cid,
CASE WHEN cid LIKE 'NAS%' THEN SUBSTRING(cid, 4, LEN(cid)) -- extract start at 4. This will Remove 'NAS' prefix if present
ELSE cid 
END cid,
--bdate,
CASE WHEN bdate > GETDATE() THEN NULL
    ELSE bdate
    END AS bdate, -- Set future birthdates to Null

CASE WHEN UPPER(TRIM(gen)) IN ('F', 'FEMALE') THEN 'Female'
     WHEN UPPER(TRIM(gen)) IN ('M', 'MALE') THEN 'Male'
     ELSE 'n/a'
END AS gen -- Normalize gender values and handle unknown cases 

FROM bronze.erp_cust_az12