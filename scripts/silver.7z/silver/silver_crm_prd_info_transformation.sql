/*

SELECT
    prd_id,
    prd_key,
    REPLACE((prd_key,1,5),'-','_') AS cat_id,
    prd_nm,
    prd_cost,
    prd_line,
    prd_start_dt,
    prd_end_dt
FROM bronze.crm_prd_info
WHERE REPLACE((prd_key,1,5),'-','_') NOT IN 
-- Selects all unique values from the id column in that table.
(SELECT distinct id from bronze.erp_px_cat_g1v2)

-- Filters out unmatched data after applying transformation 



 */



/*

SUBSTRING(column, start_position, length) is a standard SQL string function.

prd_key is the input string.

7 is the start position — this means it skips the first 6 characters.

LEN(prd_key) is the length of the full string.

So if prd_key has 10 characters, this will try to get characters 7 to 10 (i.e., last 4 characters).

⚠️ Some SQL dialects (like SQL Server) use LEN(), others use LENGTH(), e.g., in MySQL.
 
 */

PRINT '>> Truncating Table: silver.crm_prd_info'
TRUNCATE TABLE silver.crm_prd_info;
PRINT '>> Insert Data Into: silver.crm_prd_info'
INSERT INTO silver.crm_prd_info(
    prd_id,
    cat_id, -- Add เพิ่มทีหลัง AS METADATA 
    prd_key,
    prd_nm,
    prd_cost,
    prd_line,
    prd_start_dt, -- เปลี่ยน DATETIME เป็น DATE
    prd_end_dt, -- เปลี่ยน DATETIME เป็น DATE


)
SELECT
    prd_id,
    REPLACE((prd_key,1,5),'-','_') AS cat_id, -- Extract category ID 
    SUBSTRING(prd_key, 7 , LEN(prd_key)) AS prd_key, -- Extract product key
    prd_nm,
    ISNULL(prd_cost,0) AS prd_cost, -- Replace null to 0 

CASE UPPER(TRIM(prd_line)) 
     WHEN 'M' THEN 'Mountain'
     WHEN 'R' THEN 'Road'
     WHEN 'S' THEN 'other Sales'
     WHEN 'T' THEN 'Touring'
     ELSE 'n/a'
END AS prd_line, -- Map product line code to descriptive values
    CAST (prd_start_dt AS DATE) as prd_start_dt,
    LEAD(prd_start_dt) OVER (PARTITION BY prd_key ORDER BY prd_start_dt)-1 AS prd_end_dt -- งงมากก
    prd_end_dt -- Calculate end date as one day before the next start date 
FROM bronze.crm_prd_info
WHERE SUBSTRING(prd_key,7,LEN(prd_key)) NOT IN (
SELECT sls_prd_key FROM bronze.crm_sales_details)


