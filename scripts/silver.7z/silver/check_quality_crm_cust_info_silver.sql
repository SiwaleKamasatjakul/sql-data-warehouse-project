-- Check For Nulls or Duplicates in Primary Key 
-- Expectation: No Result

/*

SELECT 
cst_id,
COUNT(*)
FROM silver.crm_cust_info
GROUP BY cst_id
HAVING COUNT(*) > 1 OR cst_id IS NULL

 */


-- Check for unwanted Spaces 
-- Expectation: No Results
/*

SELECT cst_firstname
From silver.crm_cust_info
WHERE cst_firstname != TRIM(cst_firstname)

SELECT cst_lastname
From silver.crm_cust_info
WHERE cst_lastname != TRIM(cst_lastname)

SELECT cst_gndr
From silver.crm_cust_info
WHERE cst_gndr != TRIM(cst_gndr)

 */

-- Data Standardization & Consistency
/*
SELECT DISTINCT cst_gndr
FROM silver.crm_cust_info
 */


-- Result cst_gndr show only unique data to check what data it is 
/*
SELECT DISTINCT cst_marital_status
FROM silver.crm_cust_info
 */
