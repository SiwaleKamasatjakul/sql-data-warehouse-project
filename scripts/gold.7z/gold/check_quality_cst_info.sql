
SELECT DISTINCT -- Check data ที่จอยสองอันว่าเป็นยังไง เพราะเป็น table gender เหมือนกัน 

ci.cst_gndr,
ca.gen
CASE 
  WHEN ci.cst_gndr != 'n/a' THEN ci.cst_gndr  -- CRM is the Master for gender Info 
  ELSE COALESCE(ca.gen, 'n/a')
END AS new_gen

FROM silver.crm_cust_info ci 
LEFT JOIN silver.erp_cust_az12 ca 
ON ci.cst_key = ca.cid
LEFT JOIN silver.erp_loc_a101 la 
ON ci_cst_key = la.cid
ORDER BY 1,2

-- บางทีที่ได้ NULL เพราะเกิดจากการ join ข้อมูล data ใน ci.cst_gndr อาจจะไม่แมชอะไรอะไรลยใน ca 
-- ถ้าค่ามันไม่ตรงกันเช่น gender male กับ female ไม่เหมือนกันทั้งสองอันก็ต้องไปเช็คว่าอันไหนคือ master sheet จริงๆ 
-- The Master Source of Customer DATA is CRM 
-- พอรู้ว่าอันไหนใช้ได้ก็ create rule 

/*

If CRM has 'n/a', then:

Use the gender value from the ERP table (ca.gen) if ca.gen not NULL.

If ca.gen is also NULL, default to 'n/a'.

 */


-- Check quality gold customer 

 SELECT distinct gender FROM gold.dim_customers